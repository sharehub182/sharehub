import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import uuid

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Change this in production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Database Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class SharedItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    content_type = db.Column(db.String(10))  # 'file' or 'link'
    file_path = db.Column(db.String(300))
    link_url = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('shared_items', lazy=True))
    share_code = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))

# User loader function
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('register'))
        
        user = User(username=username, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    user_items = SharedItem.query.filter_by(user_id=current_user.id).order_by(SharedItem.created_at.desc()).all()
    return render_template('dashboard.html', items=user_items)

@app.route('/share', methods=['GET', 'POST'])
@login_required
def share():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        content_type = request.form['content_type']
        
        if content_type == 'file':
            file = request.files['file']
            if file and file.filename:
                filename = secure_filename(file.filename)
                unique_filename = f"{uuid.uuid4().hex}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                file.save(file_path)
                
                new_item = SharedItem(
                    title=title,
                    description=description,
                    content_type='file',
                    file_path=unique_filename,
                    user_id=current_user.id
                )
                
                db.session.add(new_item)
                db.session.commit()
                flash('File shared successfully!')
                return redirect(url_for('dashboard'))
            else:
                flash('Please select a file')
        
        elif content_type == 'link':
            link_url = request.form['link_url']
            if link_url:
                new_item = SharedItem(
                    title=title,
                    description=description,
                    content_type='link',
                    link_url=link_url,
                    user_id=current_user.id
                )
                
                db.session.add(new_item)
                db.session.commit()
                flash('Link shared successfully!')
                return redirect(url_for('dashboard'))
            else:
                flash('Please enter a valid URL')
    
    return render_template('share.html')

@app.route('/shared/<share_code>')
def shared_content(share_code):
    item = SharedItem.query.filter_by(share_code=share_code).first_or_404()
    return render_template('shared_content.html', item=item)

@app.route('/download/<share_code>')
def download_file(share_code):
    item = SharedItem.query.filter_by(share_code=share_code).first_or_404()
    if item.content_type != 'file':
        flash('This item is not a file')
        return redirect(url_for('shared_content', share_code=share_code))
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], item.file_path)
    return send_file(file_path, as_attachment=True, download_name=item.file_path.split('_', 1)[1])

# Initialize database
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)